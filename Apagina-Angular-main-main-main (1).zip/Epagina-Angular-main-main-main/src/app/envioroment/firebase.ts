export const fireBaseconfing = {
  apiKey: 'AIzaSyDScbNAZBgwazbNrLlV6OyUZuUVDWf_Cn4',
  authDomain: 'parcatica-angular.firebaseapp.com',
  projectId: 'parcatica-angular',
  storageBucket: 'parcatica-angular.appspot.com',
  messagingSenderId: '854474903946',
  appId: '1:854474903946:web:4d4221a8aefaaf8718f873',
  measurementId: 'G-DV9ZVQR00V',
};
